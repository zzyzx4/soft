from django.apps import AppConfig


class SenderConfig(AppConfig):
    name = 'sender'
